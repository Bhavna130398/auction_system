// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.


// 192.168.43.247
export const environment = {
  production: false,
  ApiUrl: 'http://localhost:3000/'
};
