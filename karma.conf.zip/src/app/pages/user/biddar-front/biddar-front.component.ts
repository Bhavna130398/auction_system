import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-biddar-front',
  templateUrl: './biddar-front.component.html',
  styleUrls: ['./biddar-front.component.css']
})
export class BiddarFrontComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
