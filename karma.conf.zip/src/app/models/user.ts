export class User {
    DOB: Date
    address: string
    email: string
    gender: string
    isVerified: boolean
    mobileNumber: number
    name: string
    password: string
    role: string
    userName: string
    _id: number
}